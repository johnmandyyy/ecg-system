from datetime import datetime
from django.core.handlers.asgi import ASGIRequest
from django.core.handlers.wsgi import WSGIRequest
import traceback as trb
from app.models import AppLogs, StackTrace
import json
from rest_framework.request import Request
from django.db import transaction
from app.constants import app_constants

class LogTypes:
    """A class definitions for types of log."""

    def __init__(self) -> None:

        self.FUNCTION = "FUNCTION"
        self.HTTP_REQUEST = "HTTP REQUEST"  # This can be used for HTTP Request logging.
        
class Levels:
    """A class definitions for levels"""

    def __init__(self) -> None:

        self.INFO = "INFO"
        self.WARNING = "WARNING"
        self.ERROR = "ERROR"

class Logger:
    """A customized logger with database integration for centralized logging."""

    LEVELS = Levels()
    LOG_TYPES = LogTypes()

    def __init__(
        self,
        request: ASGIRequest,
        level: str,
        log_type: LogTypes,
        source=None,
        message="No message defined.",
        response_status=None,
        response_data=None,
        exception=None,
        exec_time=0,
    ):
        """Used to initialize logging."""

        self.__level = level # Levels of Logging
        self.__log_type = log_type # Function or Request
        self.__request = request # Contains Request
        self.__source = source # Contains the Source Where the Python Module Does Exist
        self.__message = message # A Reserved Parameter to Log Anything
        self.__response_data = response_data # Can be used to put response data.
        self.__response_status = response_status # A Response Status for HTTP Request(s)
        self.__exception = exception # Exception

        self.__log_entry = {} # A Dictionary Object that Contains the Log Itself
        self.__exec_time = exec_time # Execution Time

        self.__validate_data()
        self.__log()
    
    # --------------------------------------------------------------------------------------------------------------- #
    def __format_data(self):
        """Use to format data."""

        TIME_NOW = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

        if (
            isinstance(self.__request, ASGIRequest)
            or isinstance(self.__request, WSGIRequest)
            or isinstance(self.__request, Request)
        ):

            self.__log_entry = {
                "timestamp": TIME_NOW,
                "logtype": self.LOG_TYPES.HTTP_REQUEST,
                "level": self.__level,
                "source": self.__source,
                "message": self.__message,
                "context": {"user_id": str(self.__request.user), "session_id": None},
                "metadata": {
                    "ip_address": self.__request.META.get("REMOTE_ADDR"),
                    "request_method": self.__request.META.get("REQUEST_METHOD"),
                    "request_path": self.__request.META.get("PATH_INFO"),
                    "response_status": self.__response_status,
                    "data": self.__response_data,
                    "error": {
                        "error_type": (
                            None
                            if self.__exception == None
                            else str(type(self.__exception).__name__)
                        ),
                        "error_message": (
                            None if self.__exception == None else str(self.__exception)
                        ),
                        "stack_trace": (
                            None if self.__exception == None else self.__trace_stack()
                        ),
                    },
                    "execution_time_ms": self.__exec_time,
                },
            }

        else: #Executed when a non HTTP Request was executed.

            self.__log_entry = {
                "timestamp": TIME_NOW,
                "logtype": self.LOG_TYPES.FUNCTION,
                "level": self.__level,
                "source": self.__source,
                "message": self.__message,
                "context": {"user_id": None, "session_id": None},
                "metadata": {
                    "ip_address": None,
                    "request_method": None,
                    "request_path": None,
                    "response_status": None,
                    "data": self.__response_data,
                    "error": {
                        "error_type": (
                            None
                            if self.__exception == None
                            else str(type(self.__exception).__name__)
                        ),
                        "error_message": (
                            None if self.__exception == None else str(self.__exception)
                        ),
                        "stack_trace": (
                            None if self.__exception == None else self.__trace_stack()
                        ),
                    },
                    "execution_time_ms": self.__exec_time,
                },
            }

    # --------------------------------------------------------------------------------------------------------------- #
    def __format_frame_summary(self, frame_summary):
        """Format traceback for cleaner look."""
        return f'{frame_summary.filename}", line {frame_summary.lineno}, in {frame_summary.name}'

    # --------------------------------------------------------------------------------------------------------------- #
    def __trace_stack(self):
        """Returns a clean stack trace with formmatted."""

        formatted_stack = []
        extracted_stack = trb.extract_stack()
        if len(extracted_stack) > 0:
            for each_stacks in extracted_stack:
                formatted_stack.append(self.__format_frame_summary(each_stacks))

        return formatted_stack

    # --------------------------------------------------------------------------------------------------------------- #
    def __validate_data(self) -> None:
        """Used for validating datas"""

        if self.__level not in [
            self.LEVELS.INFO,
            self.LEVELS.WARNING,
            self.LEVELS.ERROR,
        ]:
            raise ("Invalid level.")

        if self.__log_type not in [
            self.LOG_TYPES.FUNCTION,
            self.LOG_TYPES.HTTP_REQUEST,
        ]:
            raise ("Invalid log type.")

        self.__format_data()

    # --------------------------------------------------------------------------------------------------------------- #
    def record_to_db(self):
        """To record logs in database."""
        
        has_request = None
        
        if self.__request == None:
            has_request = None
        else:
            has_request = self.__request.user

        try:
            
            with transaction.atomic():
                    
                new_object = AppLogs.objects.create(
                    time_stamp=self.__log_entry.get("timestamp"),
                    log_type=self.__log_entry.get("logtype"),
                    level=self.__log_entry.get("level"),
                    source=self.__log_entry.get("source"),
                    message=self.__log_entry.get("message"),
                    user_id=has_request,
                    session_id=None,  # Pending
                    ip_address= None if self.__log_entry.get("metadata") == None else self.__log_entry.get("metadata").get("ip_address"),
                    request_method=None if self.__log_entry.get("metadata") == None else self.__log_entry.get("metadata").get("request_method"),
                    request_path= None if self.__log_entry.get("metadata") == None else self.__log_entry.get("metadata").get("request_path"),
                    response_status=None if self.__log_entry.get("metadata") == None else self.__log_entry.get("metadata").get("response_status"),
                    data=json.dumps({}) if self.__log_entry.get("metadata") == None else json.dumps(self.__log_entry.get("metadata").get("data")),
                    error_type=self.__log_entry.get("metadata")
                    .get("error")
                    .get("error_type"),
                    error_message=self.__log_entry.get("metadata")
                    .get("error")
                    .get("error_message"),
                    execution_time=self.__log_entry.get("metadata").get(
                        "execution_time_ms"
                    ),
                )

                if self.__exception != None:
                    for each_stacks in self.__trace_stack():
                        StackTrace.objects.create(app_log = AppLogs.objects.get(id = new_object.pk), description =str(each_stacks))

        except Exception as e:
            pass

    # --------------------------------------------------------------------------------------------------------------- #
    def record_to_text(self):
        """To record logs in notes."""
        
        has_request = None
        
        if self.__request == None:
            has_request = None
        else:
            has_request = self.__request.user.username
            
        try:
                new_object_data = {
                    "time_stamp": self.__log_entry.get("timestamp"),
                    "log_type": self.__log_entry.get("logtype"),
                    "level": self.__log_entry.get("level"),
                    "source": self.__log_entry.get("source"),
                    "message": self.__log_entry.get("message"),
                    "user_id": has_request,
                    "session_id": None,  # Pending
                    "ip_address": self.__log_entry.get("metadata", {}).get("ip_address"),
                    "request_method": self.__log_entry.get("metadata", {}).get("request_method"),
                    "request_path": self.__log_entry.get("metadata", {}).get("request_path"),
                    "response_status": self.__log_entry.get("metadata", {}).get("response_status"),
                    "data": json.dumps(self.__log_entry.get("metadata", {}).get("data", {})),
                    "error_type": self.__log_entry.get("metadata", {}).get("error", {}).get("error_type"),
                    "error_message": self.__log_entry.get("metadata", {}).get("error", {}).get("error_message"),
                    "execution_time": self.__log_entry.get("metadata", {}).get("execution_time_ms"),
                }

                append_line = json.dumps(new_object_data)
                file_path = "app/logs/textlogs/logs.txt"  # Change this to your file's path

                with open(file_path, "a") as file:
                    file.write("\n"+ append_line)
                                
        except Exception as e:
            print(e)
    
    # --------------------------------------------------------------------------------------------------------------- #
    def __log(self):
        """Default method for logging."""
        if app_constants.HAS_LOGGING == True:
            if app_constants.IS_DATABASE_LOGGING == True:
                self.record_to_db()
            else:
                self.record_to_text()
            
        return self.__log_entry
